package com.ie;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.http.client.ClientProtocolException;

public class CrawlerMain {

	public static void main(String[] args) throws SQLException, ClientProtocolException, IOException {
		// TODO Auto-generated method stub
		String frontpage = "http://johnhany.net/";
		Connection conn = null;
		

		try {
			Class.forName("com.mysql.jdbc.Driver");
			String dburl = "jdbc:mysql://localhost:3306?useUnicode=true&characterEncoding=utf8";
			conn = DriverManager.getConnection(dburl, "root", "123456");
			System.out.println("connection built");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		String sql = null;
		String url = frontpage;
		Statement stmt = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		
		if(conn != null) {

			try {
				sql = "CREATE DATABASE IF NOT EXISTS crawler";
				stmt = conn.createStatement();
				stmt.executeUpdate(sql);
				
				sql = "USE crawler";
				stmt = conn.createStatement();
				stmt.executeUpdate(sql);
				
				sql = "create table if not exists record (recordID int(5) not null auto_increment, URL text not null, crawled tinyint(1) not null, primary key (recordID)) engine=InnoDB DEFAULT CHARSET=utf8";
				stmt = conn.createStatement();
				stmt.executeUpdate(sql);
				
				sql = "create table if not exists tags (tagnum int(4) not null auto_increment, tagname text not null, primary key (tagnum)) engine=InnoDB DEFAULT CHARSET=utf8";
				stmt = conn.createStatement();
				stmt.executeUpdate(sql);
				
				sql = "INSERT INTO record (URL, crawled) VALUES ('" + frontpage + "',0)";
            			pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            			pstmt.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			conn.close();
			conn = null;
			
			System.out.println("Done.");
			System.out.println(count);
		}
	}

}
