package com.ie;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;

public class WriteTxt {
	public static boolean writeTxt(String bookinfo,String url,int n,boolean flag) throws IOException  {
		  FileOutputStream o=null;  
		  String[] bookInfoName= {"url:","bookName:","salePrice:","originalPrice:","recommend:","comment:","author:","press:","time:","ISBN:","classify:","popularity:",":"};
		  String fileName="/home/wyb/book/b"+n+".txt";
		  String[] bookinfostr=bookinfo.split("#");
		  if(bookinfostr.length<9)
			  return false;
		  OutputStreamWriter output = new OutputStreamWriter(new FileOutputStream(fileName,true),"gb2312");
		  BufferedWriter bw = new BufferedWriter(output);
		  if(!flag){
			  bw.write("\n");
		  }
		  int count=0;
		  bw.write(bookInfoName[count++]);
		  bw.write(url);
		  bw.write("\n");
		  bw.write(bookInfoName[count++]);
		  bw.write(bookinfostr[0].substring(bookinfostr[0].indexOf("《"), bookinfostr[0].indexOf("》")+1));
		  bw.write("\n");
		  for(int i=1;i<3;i++){
			  bw.write(bookInfoName[count++]);
			  bw.write(bookinfostr[i]);
			  bw.write("\n");
		  }		  
		  for(int i=3;i<bookinfostr.length-9;i++){
			if(bookinfostr[i].equals("推荐")){
					 bw.write("recommend:");
					  bw.write(bookinfostr[i-1]);
					  bw.write("\n");
				}
			else if(bookinfostr[i].equals("条")){
				 if(!bookinfostr[i-2].equals("推荐")){
					 bw.write("recommend:");
					  bw.write("null");
					  bw.write("\n");
				 }
				 bw.write("comment:");
				  bw.write(bookinfostr[i-1]);
				  bw.write("\n");
			}
			else if(bookinfostr[i].equals("作者")){
				bw.write("author:");
				if(bookinfostr[i+1].equals("出版社")){
					bw.write("null");
				}
				else
					bw.write(bookinfostr[i+1]);
				bw.write("\n");
			}
			
			else if(bookinfostr[i].equals("出版社")){
				bw.write("press:");
				if(bookinfostr[i+1].equals("出版时间")){
					bw.write("null");
				}
				else
				   bw.write(bookinfostr[i+1]);
				bw.write("\n");
			}
			else if(bookinfostr[i].equals("出版时间")){
				bw.write("time:");
				if(bookinfostr[i+1].equals("ＩＳＢＮ")){
					bw.write("null");
				}
				else
				   bw.write(bookinfostr[i+1]);
				bw.write("\n");
			}
			
			else if(bookinfostr[i].equals("ＩＳＢＮ")){
				bw.write("ISBN:");
				if(bookinfostr[i+1].equals("所属分类")){
					bw.write("null");
				}
				else
				   bw.write(bookinfostr[i+1]);
				bw.write("\n");
			}	
			else if(bookinfostr[i].equals("所属分类")){
					  bw.write("classify:");
					  for(int j=i+1;j<bookinfostr.length-9;j++){
						  if(bookinfostr[j].equals("图书"))
							  bw.write("#");
					      bw.write(bookinfostr[j]);
					      bw.write("%");
					  }
				}
		  }
		  bw.write("\n");
		  for(int i=bookinfostr.length-9;i<bookinfostr.length;i++){
			  bw.write(bookinfostr[i]);
			  bw.write("\n");
		  }
		  bw.close();
		  output.close(); 
		  return true;  
	}
}
