package com.ie;

import java.util.HashSet;
import java.util.Set;

import org.htmlparser.Node;
import org.htmlparser.NodeFilter;
import org.htmlparser.Parser;
import org.htmlparser.filters.NodeClassFilter;
import org.htmlparser.filters.OrFilter;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;

public class HtmlParserTool {
	// 获取一个网站上的链接,filter 用来过滤链接
	public static Set<String> extracLinks(String url) {

		Set<String> links = new HashSet<String>();
		String url4 = "http://product.dangdang.com/";
		String url1="http://book.dangdang.com/";
		String url2="http://category.dangdang.com";
		String url3="http://bang.dangdang.com/books/";
		try {
			Parser parser = new Parser(url);
			parser.setEncoding("GB2312");
			final String patternString = "< a\\s*?href=([^>]*?)>(.*?)< /a>";
			// 过滤 <frame >标签的 filter，用来提取 frame 标签里的 src 属性所表示的链接
			NodeFilter frameFilter = new NodeFilter() {
				public boolean accept(Node node) {
					if (node.getText().startsWith(patternString)) {
						return true;
					} else {
						return false;
					}
				}
			};
			// OrFilter 来设置过滤 <a> 标签，和 <frame> 标签
			OrFilter linkFilter = new OrFilter(new NodeClassFilter(
					LinkTag.class), frameFilter);
			// 得到所有经过过滤的标签
			NodeList list = parser.extractAllNodesThatMatch(linkFilter);
			for (int i = 0; i < list.size(); i++) {
				 Node node = (Node)list.elementAt(i);
				 if (node instanceof LinkTag){
				   LinkTag link = (LinkTag) node;
				   String linkUrl = link.getLink();// url
				   if(linkUrl.startsWith(url1)||linkUrl.startsWith(url2)||linkUrl.startsWith(url3)||linkUrl.startsWith(url4)){
				   links.add(linkUrl);
				   }
				 }               
			}
		} catch (ParserException e) {
			e.printStackTrace();
		}
		return links;
	}
	//测试的 main 方法
	public static void main(String[]args)
	{
Set<String> links = HtmlParserTool.extracLinks(
"http://book.dangdang.com");
		for(String link : links)
			System.out.println(link);
	}
}
