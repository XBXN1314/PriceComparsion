package com.ie;

import java.io.IOException;
import java.util.Set;

import org.apache.http.client.ClientProtocolException;
public class Crawler {
	/* 使用种子 url 初始化 URL 队列*/
	private void initCrawlerWithSeeds(String[] seeds)
	{
		for(int i=0;i<seeds.length;i++)
			LinkDB.addUnvisitedUrl(seeds[i]);
	}
	
	/* 爬取方法*/
	public void crawling(String[] seeds) throws ClientProtocolException, IOException
	{
		LinkFilter filter = new LinkFilter(){
			public boolean accept(String url) {
				return true;
			}
		};
		//初始化 URL 队列
		initCrawlerWithSeeds(seeds);
		int bookNum=0;
		int fileNum=1;
		//循环条件：待抓取的链接不空且抓取的网页不多于 1000
		while(!LinkDB.unVisitedUrlsEmpty()&&LinkDB.getVisitedUrlNum()<=1000)
		{
			//队头 URL 出对
			String mainurl = "http://product.dangdang.com/";
			String url4 = "http://product.dangdang.com/";
			String url1="http://book.dangdang.com/";
			String url2="http://category.dangdang.com";
			String url3="http://bang.dangdang.com/books/";
			String visitUrl=LinkDB.unVisitedUrlDeQueue();
			if(visitUrl==null||!(visitUrl.startsWith(url1)||visitUrl.startsWith(url2)||visitUrl.startsWith(url3)||visitUrl.startsWith(url4)))
				continue;
			//该 url 放入到已访问的 URL 中
			LinkDB.addVisitedUrl(visitUrl);
			System.out.println(visitUrl);
			//提取出下载网页中的 URL
			ContentParserTool contentParser = new ContentParserTool();
		
			if (visitUrl.startsWith(mainurl)){				    
					String bookInfo=contentParser.extracContent(visitUrl, "gb2312");
					bookNum=bookNum+1;
					boolean flag=false;
					if(bookNum>100){
						bookNum=1;				
						fileNum=fileNum+1;					
					}
					if(bookNum==1){
						flag=true;
					}
					WriteTxt writeT=new WriteTxt();
					writeT.writeTxt(bookInfo,visitUrl,fileNum,flag);
			}
			Set<String> links=HtmlParserTool.extracLinks(visitUrl);
			//新的未访问的 URL 入队
			for(String link:links)
			{
					LinkDB.addUnvisitedUrl(link);
			}
		}
	}
	//main 方法入口
	public static void main(String[] args) throws ClientProtocolException, IOException
	{
		Crawler crawler = new Crawler();
		crawler.crawling(new String[]{"http://book.dangdang.com/"});
	}
}