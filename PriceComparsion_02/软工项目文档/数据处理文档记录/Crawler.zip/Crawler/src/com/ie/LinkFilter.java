package com.ie;

public interface LinkFilter {
	public boolean accept(String url);
}
