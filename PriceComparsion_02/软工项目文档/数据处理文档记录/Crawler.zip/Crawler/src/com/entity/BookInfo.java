package com.entity;

public class BookInfo {

	/**
	 * @author wyb
	 * @param
	 * bookName:书名
	 * bookPrice:价格
	 * bookAuthor：作者
	 * bookPress：出版社
	 * bookDate：日期
	 * bookINBS：INBS
	 * bookClassifyA：A级分类
	 * bookClassifyB：B级分类
	 * bookClassifyC：C级分类
	 * bookContent：内容
	 */
	private String bookName;
	private int bookPrice;
	private String bookAuthor;
	private String bookPress;
	private String bookDate;
	private String bookINBS;
	private String bookClassifyA;
	private String bookClassifyB;
	private String bookClassifyC;
	private String bookContent;
	
	public void setBookName(String bookName){
		this.bookName=bookName;
	}
	public String getBookName(){
		return bookName;
	}
	
	public void setBookPrice(int bookPrice){
		this.bookPrice=bookPrice;
	}
	public int getBookPrice(){
		return bookPrice;
	}
	
	public void setBookAuthor(String bookAuthor){
		this.bookAuthor=bookAuthor;
	}
	public String getBookAuthor(){
		return bookAuthor;
	}
	
	public void setBookPress(String bookPress){
		this.bookPress=bookPress;
	}
	public String getBookPress(){
		return bookPress;
	}
	
	public void setBookDate(String bookDate){
		this.bookDate=bookDate;
	}
	public String getBookDate(){
		return bookDate;
	}
	
	public void setBookINBS(String bookINBS){
		this.bookINBS=bookINBS;
	}
	public String getBookINBS(){
		return bookINBS;
	}
	
	public void setBookClassifyA(String bookClassifyA){
		this.bookClassifyA=bookClassifyA;
	}
	public String getBookClassifyA(){
		return bookClassifyA;
	}
	
	public void setBookClassifyB(String bookClassifyB){
		this.bookClassifyB=bookClassifyB;
	}
	public String getBookClassifyB(){
		return bookClassifyB;
	}
	
	public void setBookClassifyC(String bookClassifyC){
		this.bookClassifyC=bookClassifyC;
	}
	public String getBookClassifyC(){
		return bookClassifyC;
	}
	
	public void setBookContent(String bookContent){
		this.bookContent=bookContent;
	}
	public String getBookContent(){
		return bookContent;
	}
}
